﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using LockingPolicy = Thalmic.Myo.LockingPolicy;
using Pose = Thalmic.Myo.Pose;
using UnlockType = Thalmic.Myo.UnlockType;
using VibrationType = Thalmic.Myo.VibrationType;

public class PlayerMovement : MonoBehaviour {


	private Pose _lastPose = Pose.Unknown;

	public float MoveSpeeed;

	public GameObject myo = null;
	// Use this for initialization
	Rigidbody m_Rigidbody;
	void Start () {
		m_Rigidbody = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.forward * MoveSpeeed * Time.deltaTime);
		if (Input.GetKey (KeyCode.LeftArrow)) {
			transform.Rotate (new Vector3 (0, 0, -0.5f), Space.World);
		}
		if (Input.GetKey (KeyCode.RightArrow)) {
			transform.Rotate (new Vector3 (0, 0, 0.5f), Space.World);
		} 
		if (Input.GetKey (KeyCode.UpArrow)) {
			transform.Rotate (new Vector3 (0.5f, 0, 0), Space.World);
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			transform.Rotate (new Vector3 (-0.5f, 0, 0), Space.World);
		}


		ThalmicMyo thalmicMyo = myo.GetComponent<ThalmicMyo> ();

		// Update references when the pose becomes fingers spread or the q key is pressed.
		bool updateReference = false;
		if (thalmicMyo.pose != _lastPose) {
			_lastPose = thalmicMyo.pose;

			if (thalmicMyo.pose == Pose.FingersSpread) {
				//updateReference = true;

				ExtendUnlockAndNotifyUserAction (thalmicMyo);
			}
		} 
		if (thalmicMyo.pose == Pose.WaveIn) {
			//renderer.material = waveInMaterial;
			transform.Rotate (new Vector3 (0, 0, -0.3f), Space.World);
			ExtendUnlockAndNotifyUserAction (thalmicMyo);
		} else if (thalmicMyo.pose == Pose.WaveOut) {
			//renderer.material = waveOutMaterial;
			transform.Rotate (new Vector3 (0, 0, 0.3f), Space.World);
			ExtendUnlockAndNotifyUserAction (thalmicMyo);
		} else if (thalmicMyo.pose == Pose.FingersSpread) {
			//renderer.material = doubleTapMaterial;
			transform.Rotate (new Vector3 (0.3f, 0, 0), Space.World);
			ExtendUnlockAndNotifyUserAction (thalmicMyo);
		} else if (thalmicMyo.pose == Pose.Fist) {
			transform.Rotate (new Vector3 (-0.3f, 0, 0), Space.World);
			ExtendUnlockAndNotifyUserAction (thalmicMyo);
		}
		if (Input.GetKeyDown ("r")) {
			updateReference = true;
		}

		// Update references. This anchors the joint on-screen such that it faces forward away
		// from the viewer when the Myo armband is oriented the way it is when these references are taken.
		if (updateReference) {


			if (thalmicMyo.pose != _lastPose) {
				_lastPose = thalmicMyo.pose;

				// Vibrate the Myo armband when a fist is made.
				if (thalmicMyo.pose == Pose.Fist) {
					
					// Change material when wave in, wave out or double tap poses are made.
				} else if (thalmicMyo.pose == Pose.WaveIn) {
					
				} else if (thalmicMyo.pose == Pose.WaveOut) {
					
				}
			}
		}
	}

	void OnCollisionEnter(Collision other)
	{
		if (other.gameObject.tag == "Death") {
			
		}
	}

	void ExtendUnlockAndNotifyUserAction (ThalmicMyo myo)
	{
		ThalmicHub hub = ThalmicHub.instance;

		if (hub.lockingPolicy == LockingPolicy.Standard) {
			myo.Unlock (UnlockType.Timed);
		}

		myo.NotifyUserAction ();
	}
}
